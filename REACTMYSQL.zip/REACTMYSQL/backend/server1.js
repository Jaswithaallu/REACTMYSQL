import mysql from 'mysql';
import express from 'express';
import cors from 'cors';

const app = express();

app.use(cors());
// Add middleware to parse JSON bodies
app.use(express.json());
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  port: "3306",
  user: 'root',
  password: 'password',
  database: 'student'
});

// GET method to fetch students
app.get("/student", (req, res) => {
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      return res.status(500).json({ error: err });
    }

    const sql = "SELECT * FROM student";
    connection.query(sql, (queryError, data) => {
      connection.release(); // Release the connection back to the pool

      if (queryError) {
        console.error('Error executing SQL query:', queryError);
        return res.status(500).json({ error: 'Internal server error' });
      }
      return res.json(data);
    });
  });
});

// POST method to create a new student
app.post("/student", (req, res) => {
  // Extract data from the request body
  const { id, name, age} = req.body;
  console.log("Request body:", req.body); // Log the request body

  // Perform validation if necessary

  // Execute SQL INSERT query
  const sql = "INSERT INTO student (id, name, age) VALUES (?, ?, ?)";
  pool.query(sql, [id, name, age], (err, result) => {
    if (err) {
      console.error('Error executing SQL query:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    return res.status(201).json({ message: 'Student created successfully' });
  });
});

// DELETE method to delete a student
app.delete("/student/:id", (req, res) => {
    // Extract student ID from the request parameters
    const sql = "DELETE FROM student WHERE id = ?";
    const studentId = req.params.id;
  
    // Execute SQL DELETE query
   
    pool.query(sql, [studentId], (err, result) => {
      if (err) {
        console.error('Error executing SQL query:', err);
        return res.status(500).json({ error: 'Internal server error' });
      }
  
      // Check if any rows were affected by the delete operation
      if (result.affectedRows === 0) {
        // If no rows were affected, it means the student with the provided ID doesn't exist
        return res.status(404).json({ error: 'Student not found' });
      }
  
      // Student record deleted successfully
      return res.status(200).json({ message: 'Student deleted successfully' });
    });
  });
  // PUT method to update a student
  app.put("/student/:id", (req, res) => {
   
    const studentId = req.params.id;
  
    
    const { name, age } = req.body;
  

    if (!name) {
      return res.status(400).json({ error: 'Name field is required' });
    }
  
    
    const sql = "UPDATE student SET name = ?, age = ? WHERE id = ?";
    pool.query(sql, [name, age, studentId], (err, result) => {
      if (err) {
        console.error('Error executing SQL query:', err);
        return res.status(500).json({ error: 'Internal server error' });
      }
  
    
      if (result.affectedRows === 0) {
       
        return res.status(404).json({ error: 'Student not found' });
      }
 
      return res.status(200).json({ message: 'Student updated successfully' });
    });
  });

  
const PORT = 8081;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});