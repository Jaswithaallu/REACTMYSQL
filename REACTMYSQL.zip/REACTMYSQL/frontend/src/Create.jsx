import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Create() {
    const [id, setid] = useState('');
    const [name, setname] = useState('');
    const [age, setage] = useState('');
    const navigate = useNavigate();

    function handleSubmit(event) {
        event.preventDefault();
        axios.post('http://localhost:8081/student', {id, name, age})
            .then(res => {
                console.log(res);
                navigate('/');
            })
            .catch(err => console.error(err));
    }

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-50 bg-white rounded p-3">
                <form onSubmit={handleSubmit}>
                    <h2>Add Student</h2>
                    <div className="mb-2">
                      
                        <input 
                            type="text" 
                            id="dept" 
                            placeholder="Enter Student ID" 
                            className="form-control"
                            value={id}
                            onChange={e => setid(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                
                        <input 
                            type="text" 
                            id="Name" 
                            placeholder="Enter Name" 
                            className="form-control"
                            value={name}
                            onChange={e => setname(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                    
                        <input 
                            type="text" 
                            id="Age" 
                            placeholder="Enter Age" 
                            className="form-control"
                            value={age}
                            onChange={e => setage(e.target.value)}
                        />
                    </div>
                    <button className="btn btn-success">Submit</button>
                    <Link to="/" className="btn btn-link">Cancel</Link>
                </form>
            </div>
        </div>
    );
}

export default Create;
