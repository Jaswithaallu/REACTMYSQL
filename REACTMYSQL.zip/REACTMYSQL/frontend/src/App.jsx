import React from "react"
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Student from "./Student"
import 'bootstrap/dist/css/bootstrap.min.css'
import Create from "./Create"
function App() {
 return (
   <BrowserRouter>
     <Routes>
       <Route path="/" element={<Student />} />
       <Route path="/Create" element={<Create />} />
     </Routes>
   </BrowserRouter>
 );

  
}

export default App