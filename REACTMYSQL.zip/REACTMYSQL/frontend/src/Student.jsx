import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Home() {
  const [students, setStudents] = useState([]);
  const [sortedStudents, setSortedStudents] = useState([]);
  const [sortOrder, setSortOrder] = useState('asc');

  useEffect(() => {
    axios.get('http://localhost:8081/student')
      .then(res => {
        setStudents(res.data);
        setSortedStudents([...res.data]); // Set both original and sorted student lists initially
      })
      .catch(err => console.error(err));
  }, []);

  // Function to toggle sort order and sort students by ID
  const sortStudentsById = () => {
    const sortedStudentsById = [...sortedStudents].sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.id - b.id;
      } else {
        return b.id - a.id;
      }
    });
    setSortedStudents(sortedStudentsById);
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'); // Toggle sort order
  };

  // Function to delete a student by ID
  const deleteStudent = (id) => {
    const confirmation = window.confirm('Do you want to delete permanently?');
    if (confirmation) {
      axios.delete(`http://localhost:8081/student/${id}`)
        .then(res => {
          console.log(res.data);
          // Filter out the deleted student from the list
          const updatedStudents = students.filter(student => student.id !== id);
          setStudents(updatedStudents);
          setSortedStudents(updatedStudents); // Update sorted students list
        })
        .catch(err => console.error(err));
    }
  };

  return (
    <div className='d-flex vh-100 bg-primary justify-content-center align-items-center'>
      <div className='w-50 bg-white rounded p-3'>
    
        <h2>Student List</h2>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <button className='btn btn-primary' onClick={sortStudentsById}>
            Sort by ID {sortOrder === 'asc' ? '↑' : '↓'}
          </button>
          <Link to="/Create" className='btn btn-success'>Add +</Link>
        </div>
        
        <table className='table'>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedStudents.map((student) => (
              <tr key={student.id}>
                <td>{student.id}</td>
                <td>{student.name}</td>
                <td>{student.age}</td>
                <td>
                  <button className='btn btn-sm btn-primary'>
                    <Link to={`/Update/${student.id}`} className='text-white text-decoration-none'>Update</Link>
                  </button>
                  <button className='btn btn-sm btn-danger' onClick={() => deleteStudent(student.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Home;
